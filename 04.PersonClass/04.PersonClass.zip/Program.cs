﻿using System;
using System.Text.RegularExpressions;


class Program
{
    static void Main(string[] args)
    {
        
    }
}

